### App documentaion 
TODO

### Change Log
- 24-04-2020__v2.9.26_121
    - Prep/Waste management were not deleting the non updateable fields for batch
    - Missing condition for alerts, causing error in batch
    - "Enable Alert" checkbox on contact detail doesn't behave correctly
    - Message on ItemOnSite.html (Inspectino item list page) doesn't appear sometimes